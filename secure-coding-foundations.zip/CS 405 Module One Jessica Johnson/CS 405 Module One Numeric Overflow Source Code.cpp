/*
* CS 405 Secure Coding
* Module One: Numeric Overflow/Underflow
* Jessica Johnson
* 01/09/2026
* 
* This program shows safe addition/subtraction across multiple C++ types.
* It detects and prevents numeric overflow/underflow during iterative mathematical operations, and
* reports success/failures back to the calling test functions using a boolean status.
* 
* Integers: check bounds using std::numeric_limits<T>::max()/min() before each operation.
* Floating Point: detect non-finite results(inf) using std::isfinite().
* 
* The program ensures that unsafe arithemitic operations are prevented and that 
* execution continues safely without undefined behavior.
*/

// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // Type name reporting for test output (typeid)
#include <cmath>        // Floating-point validity checks (std::isinfinite)


/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>

// add_numbers
// Interger overflow check: if result + increment exceeds max, stop early
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps, bool& overflowed)
{
    overflowed = false;
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if constexpr (std::numeric_limits<T>::is_integer)
        {
            // handle positive increment
            if (increment > 0 && result > (std::numeric_limits<T>::max() - increment))
            {
                overflowed = true;
                return result; // last safe value
            }
        }
        else
        {
            // floating point: detect if next add becomes inf
            T next = result + increment;
            if (!std::isfinite(static_cast<long double>(next)))
            {
                overflowed = true;
                return result;
            }
        }

        result += increment;
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

// subrtract_numbers
// Unsigned underflow check: If result < decrement, subtraction would wrap around
// Signed underflow check: if result - decrement would go below min, stop early
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, bool& underflowed)
{
    underflowed = false;
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if constexpr (std::numeric_limits<T>::is_integer)
        {
            // unsigned underflow (wrap)
            if constexpr (!std::numeric_limits<T>::is_signed)
            {
                if (result < decrement)
                {
                    underflowed = true;
                    return result; // last safe value
                }
            }
            else
            {
                // signed underflow (below min)
                if (decrement > 0 && result < (std::numeric_limits<T>::min() + decrement))
                {
                    underflowed = true;
                    return result;
                }
            }
        }
        else
        {
            // Floating point: prevent overflow to +/- inf (isinf check)
            T next = result - decrement;
            if (!std::isfinite(static_cast<long double>(next)))
            {
                underflowed = true;
                return result;
            }
        }

        result -= decrement;
    }

    return result;
}

//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow ("
        << +start << ", " << +increment << ", " << steps << ") = ";

    bool overflowed = false;
    T result = add_numbers<T>(start, increment, steps, overflowed);

    std::cout << +result
        << " | Overflow Detected: " << std::boolalpha << overflowed
        << std::endl;

    std::cout << "\tAdding Numbers With Overflow ("
        << +start << ", " << +increment << ", " << (steps + 1) << ") = ";

    overflowed = false;
    result = add_numbers<T>(start, increment, steps + 1, overflowed);

    std::cout << +result
        << " | Overflow Detected: " << std::boolalpha << overflowed
        << std::endl;
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tSubtracting Numbers Without Underflow ("
        << +start << ", " << +decrement << ", " << steps << ") = ";

    bool underflowed = false;
    T result = subtract_numbers<T>(start, decrement, steps, underflowed);

    std::cout << +result
        << "  underflow=" << std::boolalpha << underflowed
        << std::endl;

    std::cout << "\tSubtracting Numbers With Underflow ("
        << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";

    underflowed = false;
    result = subtract_numbers<T>(start, decrement, steps + 1, underflowed);

    std::cout << +result
        << "  underflow=" << std::boolalpha << underflowed
        << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
